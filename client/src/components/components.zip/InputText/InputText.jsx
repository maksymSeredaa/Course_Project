import React, { useState, useEffect } from 'react';
import data from '../../data/data.json';
import css from './InputText.module.css';

function InputText() {
    const [currentSegmentIndex, setCurrentSegmentIndex] = useState(0);
    const [segments, setSegments] = useState([]);
    const [typedText, setTypedText] = useState('');

    useEffect(() => {
        // Split the text into segments of up to 7 words each
        const words = data.text1.split(' ');
        const tempSegments = [];
        for (let i = 0; i < words.length; i += 7) {
            tempSegments.push(words.slice(i, i + 7).join(' '));
        }
        setSegments(tempSegments);
    }, []);

    const handleTextChange = (event) => {
        const inputText = event.target.innerText;
        setTypedText(inputText);
    };

    const formatTextDisplay = () => {
        if (!segments.length) return ''; // Если сегменты пусты, ничего не делаем

        const currentSegment = segments[currentSegmentIndex];
        let displayText = '';

        for (let i = 0; i < typedText.length; i++) {
            if (i < currentSegment.length && typedText[i] === currentSegment[i]) {
                displayText += `<span style="color: blue;">${typedText[i]}</span>`;
            } else {
                break; // Прекращаем добавление текста, если символ не совпадает
            }
        }

        return displayText;
    };

    return (
        <div className={css.wrapper}>
            <div className={css.display}>
                {segments[currentSegmentIndex]} {/* Показываем текущий сегмент */}
            </div>
            <div
                contentEditable
                onInput={handleTextChange}
                className={css.editable}
                suppressContentEditableWarning={true}
                dangerouslySetInnerHTML={{ __html: formatTextDisplay() }}
            ></div>
        </div>
    );
}

export default InputText;
