import React from 'react';
import styles from '../Keyboard/Keyboard.module.css'; // Ensure the path is correct based on your project structure

function KeyboardItem({ keyData, setInput, activeKey }) {
  return (
    <button
      key={keyData.label} // Using label as key since index isn't available here
      className={`${styles.key} ${styles[keyData.class]} ${styles[`key${keyData.size.charAt(0).toUpperCase() + keyData.size.slice(1)}`]} ${activeKey.toUpperCase() === keyData.label ? styles.keyActive : ''}`}
      onClick={() => setInput(prev => prev + keyData.label)}
    >
      {keyData.label} {keyData.position ? `(${keyData.position})` : ''}
    </button>
  );
}

export default KeyboardItem;
