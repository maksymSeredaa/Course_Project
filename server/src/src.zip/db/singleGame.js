import SinglePlayerGame from '../models/singleGame';  // Adjust the import path as necessary

export default {
    // Fetch all single player games
    getAllGames() {
        return SinglePlayerGame.findAll();
    },

    // Get a single player game by ID
    async getGameById(gameId) {
        try {
            const game = await SinglePlayerGame.findByPk(gameId);
            return game;
        } catch (error) {
            console.error('Error retrieving game by ID:', error);
            throw error;
        }
    },

    // Create a new single player game
    async createGame(gameData) {
        try {
            const newGame = await SinglePlayerGame.create(gameData);
            return newGame;
        } catch (error) {
            console.error('Error creating game:', error);
            throw error;
        }
    }
};
