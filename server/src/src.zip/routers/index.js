import { Router } from 'express';
import user from './userRouters';
import duelGame from './doubleGameRouters';
import singleGame from './singleGameRouters';
const router = Router();

router.use('/user', user);
router.use('/duelGame',duelGame);
router.use('/singleGame',singleGame);

export default router;